﻿#include <iostream>

int consumption(long num_n)
{
    long consum = 1;
    for (int i = 1; i <= num_n; i++)
    {
        consum *= i;
    }
    return consum;
}
void zd1()
{
    //try
    //{   
    long num_n;
    std::cout << "Введите значение числа n\n";
    std::cin >> num_n;
    if (num_n >= 1)
    {
        long consum;
        consum = consumption(num_n);
        std::cout << "Произведение чисел от 1 до n = " << consum << std::endl;
    }
    //}
    //catch(const char* message)
    //{
    //    std::cout << "Вызвано исключение\n";
    //}
}
bool checkNum(int num1_min, int num2_max, int step)
{
    if (step <= num2_max - num1_min)
    {
        return true;
    }
    return false;
}
void outputNum(int num1_min, int num2_max, int step)
{
    std::cout << num1_min << std::endl;
    while (true)
    {
        if (num1_min + step <= num2_max)
        {
            std::cout << num1_min + step << std::endl;
            num1_min = num1_min + step;
        }
        else
            break;
    }
}
void zd2()
{
    // Вывести ряд натуральных чисел от минимума до максимума (вводит пользователь) с шагом, если шаг некорректный - сообщить.
    int num1_min, num2_max, step;
    std::cout << "Введите первое число (>=0)\n";
    std::cin >> num1_min;
    std::cout << "Введите второе число (>=0)\n";
    std::cin >> num2_max;
    std::cout << "Введите шаг\n";
    std::cin >> step;
    bool resulCheckNum = checkNum(num1_min, num2_max, step);
    if (resulCheckNum)
    {
        outputNum(num1_min, num2_max, step);
    }
    else
    {
        std::cout << "Некорректный ввод\n";
    }
}
int main()
{
    setlocale(LC_ALL, "rus");
        int num_choice;
        std::cout << "Выберите задание. Введите 1,2 или 0  в случае выхода из программы\n";
        std::cin >> num_choice;
        switch (num_choice)
        {
        case 0:
            break;
        case 1:
            zd1();
            break;
        case 2:
            zd2();
            break;
        default:
            std::cout << "Ошибка ввода\n";
            break;
        }
}
